<template>
  <section class="py-20 lg:py-24 bg-primary text-white">
    <div class="container px-6 lg:px-10 xl:px-16">
      <h2 class="text-center text-[32px] lg:text-5xl font-bold mb-10 lg:mb-16 leading-tight max-w-[250px] lg:max-w-none mx-auto">
        Engagement Options
      </h2>
      <div class="grid lg:grid-cols-2 gap-4 lg:gap-8 mb-10 lg:mb-12">
        <div 
          v-for="(option, index) in options" 
          :key="index"
          :class="['p-6 lg:p-10 rounded-xl lg:rounded-[1rem]', option.bgClass, option.textClass]"
        >
          <h3 class="text-[20px] lg:text-3xl font-bold mb-3 lg:mb-6">{{ option.title }}</h3>
          <p class="text-[14px] lg:text-base leading-relaxed" :class="option.descClass">{{ option.description }}</p>
        </div>
      </div>
      <div class="text-center">
        <a href="#" class="inline-block bg-[#F4F5F6] text-primary px-8 py-3 lg:px-8 lg:py-3.5 text-[14px] lg:text-base rounded-full font-bold hover:bg-white hover:-translate-y-1 transition-all shadow-lg">
          Discover our Packages
        </a>
      </div>
    </div>
  </section>
</template>

<script setup>
const options = [
  { 
    title: 'A single task.',
    description: 'For one obligation, one filing, or one specific question. This suits a registration, a return, a certificate application, or a one-time advisory matter.',
    bgClass: 'bg-[#F4F5F6]',
    textClass: 'text-primary',
    descClass: 'text-primary/80'
  },
  {
    title: 'Ongoing support.',
    description: 'For businesses that want their tax and accounting handled continuously through the year, rather than one filing at a time. We agree the scope once and take it from there.',
    bgClass: 'bg-lime-400',
    textClass: 'text-primary',
    descClass: 'text-primary/90'
  }
]
</script>
