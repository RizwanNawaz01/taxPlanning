<template>
  <section class="py-24 bg-white text-center">
    <div class="container px-10 xl:px-16">
      <h2 class="text-4xl xl:text-5xl font-bold text-primary mb-6">Partner with Us</h2>
      <p class="text-lg text-black max-w-2xl mx-auto mb-10">For lawyers, accountants, auditors, corporate advisors, private bankers, and wealth managers with clients who need tax expertise.</p>
      <a href="#" class="inline-block bg-primary text-white px-8 py-3 rounded-full font-semibold hover:bg-secondary hover:-translate-y-1 transition-all shadow-[0_4px_12px_rgba(11,22,44,0.2)]">Book a Consultation</a>
    </div>
  </section>
</template>
