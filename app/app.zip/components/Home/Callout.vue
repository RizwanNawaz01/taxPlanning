<template>
  <section class="py-24 bg-white px-4 lg:px-10 xl:px-16">
    <div class="container grid lg:grid-cols-2 gap-10 lg:gap-16 items-start">
      <!-- Left Side -->
      <div class="max-w-xl">
        <span class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{{ calloutContent.overline }}</span>
        <h2 class="text-4xl lg:text-[44px] font-bold text-primary leading-[1.15]" v-html="calloutContent.title"></h2>
      </div>
      
      <!-- Right Side -->
      <div class="lg:pt-10">
        <p class="text-[17px] text-black mb-8 leading-snug lg:leading-relaxed  max-w-lg xl:max-w-xl">{{ calloutContent.description }}</p>
        <Button @click="isModalOpen = true" variant="primary">
          {{ calloutContent.button.text }}
        </Button>
      </div>
    </div>

    <!-- Modal Popup for Contact Form -->
    <Modal v-model="isModalOpen">
      <ContactForm title="Enquire Now" buttonText="Submit Enquiry" />
    </Modal>
  </section>
</template>

<script setup>
import { ref } from 'vue'

const isModalOpen = ref(false)

const calloutContent = {
  overline: "BUILD FOR DECISION THAT MATTER",
  title: "Good advice starts<br/>before a decision is<br/>made.",
  description: "We work with clients while they are weighing up an investment, a new market, or a change in ownership, and want to understand the tax implications before committing to anything. That can mean a straightforward VAT or Corporate Tax filing, or a longer conversation about how a business is structured and where it's heading.",
  button: {
    text: "Enquire Now"
  }
}
</script>
