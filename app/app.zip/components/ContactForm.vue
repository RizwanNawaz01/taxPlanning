<template>
  <div class="bg-[#FBFBFB] p-10 lg:p-12 rounded-3xl shadow-2xl">
    <h3 class="text-[22px] font-bold text-center text-primary mb-10">{{ title }}</h3>
    
    <form @submit.prevent="handleSubmit" class="space-y-4">
      <div>
        <input type="text" class="w-full bg-transparent border-0 border-b border-slate-200 pb-3 px-0 text-[15px] focus:outline-none focus:border-primary focus:ring-0 placeholder:text-slate-400 transition-colors" placeholder="Full Name" required />
      </div>
      
      <div>
        <input type="email" class="w-full bg-transparent border-0 border-b border-slate-200 pb-3 px-0 text-[15px] focus:outline-none focus:border-primary focus:ring-0 placeholder:text-slate-400 transition-colors" placeholder="Email" required />
      </div>
      
      <div>
        <input type="tel" class="w-full bg-transparent border-0 border-b border-slate-200 pb-3 px-0 text-[15px] focus:outline-none focus:border-primary focus:ring-0 placeholder:text-slate-400 transition-colors" placeholder="Phone" required />
      </div>
      
      <div>
        <select class="w-full bg-transparent border-0 border-b border-slate-200 pb-3 px-0 text-[15px] focus:outline-none focus:border-primary focus:ring-0 text-slate-400 transition-colors appearance-none" required>
          <option value="" disabled selected>Service required</option>
          <option value="corporate-tax" class="text-slate-800">Corporate Tax</option>
          <option value="vat" class="text-slate-800">VAT Registration</option>
          <option value="accounting" class="text-slate-800">Accounting & Bookkeeping</option>
          <option value="other" class="text-slate-800">Other</option>
        </select>
      </div>
      
      <div>
        <textarea class="w-full bg-transparent border-0 border-b border-slate-200 pb-3 px-0 text-[15px] focus:outline-none focus:border-primary focus:ring-0 placeholder:text-slate-400 transition-colors resize-none mt-2" placeholder="Message" rows="1"></textarea>
      </div>
      
      <div class="pt-3 flex justify-center">
        <Button type="submit" variant="dark" class="w-[85%] md:w-[75%] lg:w-[72%]">
          {{ buttonText }}
        </Button>
      </div>
    </form>
  </div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    default: "Let's Discuss Your Tax Needs"
  },
  buttonText: {
    type: String,
    default: "Book a Consultation"
  }
})

const handleSubmit = () => {
  // Handle form submission logic here
  console.log('Form submitted')
}
</script>
