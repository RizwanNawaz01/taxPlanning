<template>
  <footer class="bg-primary text-white pt-20 pb-8">
    <div class="container mx-auto px-6 lg:px-10 xl:px-16">
      <!-- Logo Row -->
      <div class="mb-20">
        <NuxtLink to="/">
          <NuxtImg :src="companyInfo.logo.src" :alt="companyInfo.logo.alt" class="h-10 w-auto" />
        </NuxtLink>
      </div>

      <!-- Links Row -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-20 mb-20">
        <!-- Contact Info -->
        <div class="text-white/90 text-[15px] space-y-5">
          <p class="leading-relaxed">
            <span v-for="(line, index) in companyInfo.address" :key="index" class="block">{{ line }}</span>
          </p>
          <p><a :href="'tel:' + companyInfo.phone" class="hover:text-lime-400 transition-colors">{{ companyInfo.phone }}</a></p>
          <p><a :href="'mailto:' + companyInfo.email" class="hover:text-lime-400 transition-colors">{{ companyInfo.email }}</a></p>
        </div>
        
        <!-- Footer Columns -->
        <div v-for="(section, index) in footerLinks" :key="index">
          <ul class="space-y-5 text-white/90 text-[15px]">
            <li v-for="(link, linkIndex) in section.links" :key="linkIndex" class="flex items-center gap-3">
              <div class="w-1 h-1 bg-white rounded-full shrink-0"></div>
              <a :href="link.url" class="hover:text-lime-400 transition-colors">{{ link.text }}</a>
            </li>
          </ul>
        </div>
      </div>

      <!-- Bottom Bar -->
      <div class="pt-6 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-white/70 text-[14px]">
        <p>&copy;{{ currentYear }} taxplanning.ae</p>
        <div class="flex items-center gap-5">
          <a :href="legalLinks[0].url" class="hover:text-white transition-colors">{{ legalLinks[0].text }}</a>
          <span class="w-px h-3 bg-white/20"></span>
          <a :href="legalLinks[1].url" class="hover:text-white transition-colors">{{ legalLinks[1].text }}</a>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup>
import { computed } from 'vue'

const currentYear = computed(() => new Date().getFullYear())

const companyInfo = {
  logo: {
    src: '/logo.png',
    alt: 'taxplanning.ae'
  },
  address: [
    'Level 4, Burlington Tower, Business Bay,',
    'Dubai'
  ],
  phone: '+971 800 469',
  email: 'info@taxplanning.ae'
}

const footerLinks = [
  {
    links: [
      { text: 'Tax Compliance', url: '#' },
      { text: 'Strategic Advisory', url: '#' },
      { text: 'Corporate Tax', url: '#' },
      { text: 'VAT', url: '#' },
      { text: 'Audit Support', url: '#' }
    ]
  },
  {
    links: [
      { text: 'UAE SMEs', url: '#' },
      { text: 'International Co.', url: '#' },
      { text: 'Holding Companies', url: '#' }
    ]
  },
  {
    links: [
      { text: 'About Us', url: '#' },
      { text: 'Contact', url: '#' },
      { text: 'Privacy Policy', url: '#' },
      { text: 'Terms & Conditions', url: '#' }
    ]
  }
]

const legalLinks = [
  { text: 'Terms and conditions', url: '#' },
  { text: 'Privacy Policy', url: '#' }
]
</script>
