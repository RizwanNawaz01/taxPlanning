<template>
  <section id="why-us" class="py-24 bg-primary text-white">
    <div class="container px-10 xl:px-16">
      <div class="grid lg:grid-cols-2 gap-96 mb-16">
        <h2 class="text-4xl font-bold">Why <span class="text-lime-400">taxplanning.ae</span></h2>
        <p class="text-lg text-white/70">Tax advice should make the path forward easier to understand. We bring the filing, the structure and the decision into one conversation.</p>
      </div>
      <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div 
          v-for="(item, index) in items" 
          :key="index"
          class="bg-white/5 border border-white/10 p-8 rounded-2xl"
        >
          <span class="text-5xl font-bold text-white/20 block mb-12">{{ index + 1 }}</span>
          <h4 class="text-xl font-bold mb-4">{{ item.title }}</h4>
          <p class="text-sm text-white/60">{{ item.description }}</p>
        </div>
      </div>
      <div class="text-center pt-5">
        <Button to="#services">Explore Our Services</Button>
      </div>
    </div>
  </section>
</template>

<script setup>
const items = [
  {
    title: 'Backed by a proven track record',
    description: 'We have successfully delivered tax and accounting solutions across the UAE, saving our clients time and mitigating tax risks in complex situations.'
  },
  {
    title: 'A seamless and friendly service',
    description: 'A dedicated team in a digital environment. No confusing jargon, only clear instructions and guidance.'
  },
  {
    title: 'Every service under one roof',
    description: 'From set up to tax, compliance to advisory, we cover all areas of tax and accounting so you get comprehensive management.'
  },
  {
    title: 'Advisory you can act on',
    description: 'We build our strategy and advice around practical solutions, not just theory, so you can execute successfully.'
  }
]
</script>
