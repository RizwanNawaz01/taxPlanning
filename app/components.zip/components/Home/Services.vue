
<template>
  <section id="services" class="py-24 bg-white px-10 xl:px-16">
    <div class="container">
      <div class="flex flex-col lg:flex-row justify-between items-start lg:items-end mb-16 gap-6">
        <h2 class="text-4xl font-bold text-primary">Services</h2>
        <p class="text-black max-w-md">Our work covers the full range of tax and accounting obligations for SMEs to multinationals, along with advisory support for bigger decisions.</p>
      </div>
      <div class="grid lg:grid-cols-2 gap-8">
        <div v-for="(service, index) in services" :key="index" :class="['p-10  lg:px-12 lg:pt-24 lg:pb-16 rounded-[2rem] relative overflow-hidden', service.cardClass]">
          <img :src="service.bgImage" alt="" class="absolute inset-0 w-full h-full object-cover object-right pointer-events-none" />
          <div class="relative z-10">
            <h3 class="text-3xl font-bold mb-3">{{ service.title }}</h3>
            <p class="mb-8" :class="service.descClass" v-html="service.description"></p>
            <a :href="service.link" :class="['inline-block px-12 py-3 rounded-full font-semibold hover:-translate-y-1 transition-all', service.btnClass]">{{ service.linkText }}</a>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
const services = [
  {
    title: 'Tax & Compliance',
    description: 'VAT Registration and Filing, VAT Deregistration, Corporate Tax Registration and Filing, Corporate Tax Deregistration, Tax Residency Certificates, Accounting and Bookkeeping, Financial Reporting, Audit, AML Compliance, and Payroll.',
    link: '#',
    linkText: 'Learn more',
    cardClass: 'bg-primary text-white',
    descClass: 'text-white/80',
    btnClass: 'bg-lime-400 text-primary hover:bg-lime-500',
    bgImage: '/Home/services-left.png'
  },
  {
    title: 'Strategic Advisory',
    description: 'International Tax Planning, Residence and Domicile <br> advice, Corporate Tax and Substance, Corporate Tax <br> Consultation, and tax advisory for structuring and <br> transactions.',
    link: '#',
    linkText: 'Learn more',
    cardClass: 'bg-slate-50 text-primary',
    descClass: 'text-slate-600',
    btnClass: 'bg-primary text-white hover:bg-secondary',
    bgImage: '/Home/services-right.png'
  }
]
</script>
