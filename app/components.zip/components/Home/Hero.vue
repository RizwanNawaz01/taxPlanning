<template>
  <section class="relative pt-40 pb-24 overflow-hidden bg-cover bg-center bg-no-repeat" :style="{ backgroundImage: `url(${heroContent.bgImage})` }">
    <div class="container grid lg:grid-cols-12 gap-8 lg:gap-16 items-center relative z-10 px-10 xl:px-16">
      <!-- Left Side: Hero Content -->
      <div class="lg:col-span-7 text-white">
        <h1 class="text-5xl lg:text-6xl font-semibold leading-tight mb-6" v-html="heroContent.title"></h1>
        <p class="text-lg xl:text-xl text-white/80 mb-8 max-w-lg">{{ heroContent.description }}</p>
        <Button :to="heroContent.button.link" variant="primary">
          {{ heroContent.button.text }}
        </Button>
      </div>
      
      <!-- Right Side: Contact Form Component -->
      <div class="lg:col-span-5 z-10">
        <ContactForm 
          :title="formContent.title"
          :buttonText="formContent.buttonText"
        />
      </div>
    </div>
  </section>
</template>

<script setup>
// Make the left side (text, button, image) dynamic
const heroContent = {
  bgImage: '/Home/hero.png',
  title: 'Tax planning<br/><span class="text-lime-400">that thinks ahead.</span>',
  description: 'We help UAE businesses manage their tax obligations from registration and filing through to questions around growth and structure.',
  button: {
    text: 'Explore Our Tax Services',
    link: '#services'
  }
}

// Pass dynamic props to the form on the right side
const formContent = {
  title: "Let's Discuss Your Tax Needs",
  buttonText: "Book a Consultation"
}
</script>
