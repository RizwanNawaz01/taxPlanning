<template>
  <section class="py-24 bg-primary text-white">
    <div class="container px-10 xl:px-16">
      <h2 class="text-center text-4xl xl:text-5xl font-bold mb-16">Engagement Options</h2>
      <div class="grid lg:grid-cols-2 gap-8 mb-12">
        <div 
          v-for="(option, index) in options" 
          :key="index"
          :class="['p-10 rounded-[1rem]', option.bgClass, option.textClass]"
        >
          <h3 class="text-3xl font-bold mb-6">{{ option.title }}</h3>
          <p :class="option.descClass">{{ option.description }}</p>
        </div>
      </div>
      <div class="text-center">
        <a href="#" class="inline-block bg-slate-50 text-primary px-8 py-3.5 rounded-full font-bold hover:bg-white hover:-translate-y-1 transition-all shadow-[0_4px_14px_rgba(0,0,0,0.1)]">Discover our Packages</a>
      </div>
    </div>
  </section>
</template>

<script setup>
const options = [
  {
    title: 'A single task.',
    description: 'For one-off advice, resolving a historical issue with the tax authorities, or restructuring a structure before it trades. We act for you once.',
    bgClass: 'bg-white',
    textClass: 'text-primary',
    descClass: 'text-slate-600'
  },
  {
    title: 'Ongoing support.',
    description: 'For businesses that want a proactive tax and accounting team throughout the year, with a focus on mitigating risks and managing cashflow over the long-term.',
    bgClass: 'bg-lime-400',
    textClass: 'text-primary',
    descClass: 'text-primary/80'
  }
]
</script>
