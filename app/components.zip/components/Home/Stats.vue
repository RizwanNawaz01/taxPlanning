<template>
  <section class="py-10 bg-[#F8F9FA] px-10 xl:px-16">
    <div class="container flex flex-col md:flex-row justify-center items-center text-center divide-y md:divide-y-0 md:divide-x divide-slate-300">
      <div v-for="(stat, index) in stats" :key="index" class="flex-1 w-full py-6 md:py-2 px-4">
        <h3 class="text-[22px] lg:text-[26px] font-semibold text-black mb-2">{{ stat.value }}</h3>
        <p class="text-[15px] text-[#222] max-w-[240px] mx-auto leading-snug" v-html="stat.label"></p>
      </div>
    </div>
  </section>
</template>

<script setup>
const stats = [
  {
    value: '2000+',
    label: 'Accounting and tax <br> consultations'
  },
  {
    value: 'Specialist Team',
    label: 'Qualified CAs, ACCAs <br> and CPAs'
  },
  {
    value: 'UAE-wide',
    label: 'Mainland and free zone <br> expertise, across all 7 emirates'
  }
]
</script>
