<template>
  <section id="who-we-work-with" class="pt-12 pb-28 bg-white overflow-hidden relative">
    <div class="container mx-auto px-6 lg:px-10 xl:px-16 grid lg:grid-cols-2 gap-16 lg:gap-20 items-center relative z-10">
      
      <!-- Left Column -->
      <div class="relative flex flex-col items-center lg:items-start pt-12 lg:pt-0">
        <!-- Image -->
        <img src="/Home/who-we-work.png" alt="Who We Work With" class="relative z-10 w-[80%] max-w-[340px] xl:max-w-full -mb-[1px] object-contain" />
        
        <!-- Text Content -->
        <div class="relative z-0 w-full">
          <!-- Background Shape -->
          <div class="absolute top-0 bottom-0 right-[-1rem] lg:right-0 w-[150vw] bg-primary rounded-r-[3rem] lg:rounded-tr-[10rem] lg:rounded-br-[10rem] z-0"></div>
          
          <div class="relative z-20 px-8 pb-12 pt-8 lg:px-12 lg:pb-12 lg:pt-16 text-white text-center lg:text-left">
            <h2 class="text-3xl lg:text-[2.5rem] font-bold mb-3 leading-tight">Who We Work With</h2>
            <p class="text-white/80 mb-5 text-[15px] lg:text-[16px] leading-relaxed max-w-md mx-auto lg:mx-0">
              From a single company to an international group, we work across the structures and industries that make up the UAE economy.
            </p>
            <Button to="#">
              Book a Consultation
            </Button>
          </div>
        </div>
      </div>

      <!-- Right Column -->
      <div class="flex flex-col justify-center">
        <div 
          v-for="(item, index) in items" 
          :key="item.id"
          class="flex gap-6 lg:gap-8 pt-8"
          :class="[
            index !== items.length - 1 ? 'border-b border-gray-200 pb-8' : '',
            index === 0 ? 'pt-0' : ''
          ]"
        >
          <span class="text-gray-400 font-medium text-sm pt-1">{{ item.id }}</span>
          <div>
            <h4 class="text-[20px] lg:text-[28px] font-bold text-primary mb-3 leading-tight max-w-lg">{{ item.title }}</h4>
            <p class="text-gray-600 text-[15px] lg:text-base leading-relaxed">{{ item.description }}</p>
          </div>
        </div>
      </div>
      
    </div>
  </section>
</template>

<script setup>
const items = [
  {
    id: '01',
    title: 'Established UAE SMEs & mid-market companies',
    description: 'Small businesses, growing companies, and established mid-market enterprises across the UAE managing ongoing VAT and Corporate Tax obligations, alongside decisions on growth, ownership, or bringing in outside investment.'
  },
  {
    id: '02',
    title: 'International Companies Operating or Expanding into the UAE',
    description: 'Multinational businesses, foreign subsidiaries, and international companies setting up in the UAE or already trading here, working through how UAE tax rules apply alongside their existing structure.'
  },
  {
    id: '03',
    title: 'UAE Business Groups & Holding Companies',
    description: 'Corporates, holding companies, and multi-entity groups managing tax across more than one company, where structuring matters as much as filing.'
  },
  {
    id: '04',
    title: 'Every Industry, Every Structure',
    description: 'Mainland companies, free zone entities, startups, and long-established businesses. We work across every industry, including retail, real estate, hospitality, trading, professional services, technology, and manufacturing.'
  }
]
</script>
