<template>
  <header class="fixed top-0 left-0 right-0 z-50 pt-8 pb-4 px-4 lg:px-8 transition-all duration-300">
    <div class="container mx-auto flex justify-between items-center bg-[#1E2E45]/90 backdrop-blur-sm rounded-full px-6 lg:px-8 py-4 shadow-lg border border-white/5">
      <!-- Logo -->
      <NuxtLink to="/">
        <NuxtImg :src="logo.src" :alt="logo.alt" class="h-8 md:h-10 w-auto" />
      </NuxtLink>

      <!-- Right Side (Nav + Button) -->
      <div class="flex items-center gap-8 lg:gap-12">
        <!-- Navigation -->
        <nav class="hidden lg:block">
          <ul class="flex gap-8 text-white/90 font-medium text-[15px]">
            <li v-for="(link, index) in navLinks" :key="index">
              <NuxtLink :to="link.href" class="hover:text-lime-400 transition-colors">
                {{ link.label }}
              </NuxtLink>
            </li>
          </ul>
        </nav>

        <!-- CTA Button -->
        <a :href="ctaButton.href" class="flex items-center gap-2 text-white font-semibold text-[15px] border border-[#8EE62B]/60 px-5 py-2.5 rounded-full hover:bg-[#8EE62B]/10 transition-colors">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8EE62B" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
          {{ ctaButton.label }}
        </a>
      </div>
    </div>
  </header>
</template>

<script setup>
const logo = {
  src: '/logo.png',
  alt: 'taxplanning.ae'
}

const navLinks = [
  { label: 'Services', href: '#services' },
  { label: 'Who we work with', href: '#who-we-work-with' },
  { label: 'Our approach', href: '#our-approach' },
  { label: 'Partners', href: '#partners' },
  { label: 'About us', href: '#about-us' }
]

const ctaButton = {
  label: '+971 4 553 4844',
  href: 'tel:+97145534844'
}
</script>
